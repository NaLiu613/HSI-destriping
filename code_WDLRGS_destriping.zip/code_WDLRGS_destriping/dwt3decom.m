function [newimg3]=dwt3decom(DataTest,lambda,WS)
[num_rows, num_cols, N] = size(DataTest);

WW1=dwt3(DataTest,WS,'mode','per');
WW2=dwt3(WW1.dec{1,1,1},WS,'mode','per');
WW3=dwt3(WW2.dec{1,1,1},WS,'mode','per');
WW4=dwt3(WW3.dec{1,1,1},WS,'mode','per');

%%
 for d=1:ceil(N/2)
[LL1.dec{1,1,2}(:,:,d) WW1.dec{1,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{1,1,2}(:,:,d),lambda);
%WW1.dec{1,1,2}(:,:,d)=0;
   [LL1.dec{2,1,1}(:,:,d) WW1.dec{2,1,1}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{2,1,1}(:,:,d),lambda);  
  [LL1.dec{2,1,2}(:,:,d) WW1.dec{2,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{2,1,2}(:,:,d),lambda);
  
  %[LL1.dec{1,2,1}(:,:,d) WW1.dec{1,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{1,2,1}(:,:,d),1e1);  
 % [LL1.dec{1,2,2}(:,:,d) WW1.dec{1,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{1,2,2}(:,:,d),1e1);
%WW1.dec{1,2,2}(:,:,d)=0;

% [LL1.dec{2,2,1}(:,:,d) WW1.dec{2,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{2,2,1}(:,:,d),lambda);  
 % [LL1.dec{2,2,2}(:,:,d) WW1.dec{2,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW1.dec{2,2,2}(:,:,d),lambda);  
 end
  for d=1:ceil(N/4)
  [LL2.dec{1,1,2}(:,:,d) WW2.dec{1,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{1,1,2}(:,:,d),lambda);
  
    [LL2.dec{2,1,1}(:,:,d) WW2.dec{2,1,1}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{2,1,1}(:,:,d),lambda);  
  [LL2.dec{2,1,2}(:,:,d) WW2.dec{2,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{2,1,2}(:,:,d),lambda);
  
 % [LL2.dec{1,2,1}(:,:,d) WW2.dec{1,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{1,2,1}(:,:,d),1e1);  
 % [LL2.dec{1,2,2}(:,:,d) WW2.dec{1,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{1,2,2}(:,:,d),1e1);
%WW2.dec{1,2,2}(:,:,d)=0;
%  [LL2.dec{2,2,1}(:,:,d) WW2.dec{2,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{2,2,1}(:,:,d),lambda);  
 % [LL2.dec{2,2,2}(:,:,d) WW2.dec{2,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW2.dec{2,2,2}(:,:,d),lambda);  
  end
   for d=1:ceil(N/8)
   [LL3.dec{1,1,2}(:,:,d) WW3.dec{1,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{1,1,2}(:,:,d),lambda);
  
[LL3.dec{2,1,1}(:,:,d) WW3.dec{2,1,1}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{2,1,1}(:,:,d),lambda);  
  [LL3.dec{2,1,2}(:,:,d) WW3.dec{2,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{2,1,2}(:,:,d),lambda);
   
  % [LL3.dec{1,2,1}(:,:,d) WW3.dec{1,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{1,2,1}(:,:,d),lambda);  
 % [LL3.dec{1,2,2}(:,:,d) WW3.dec{1,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{1,2,2}(:,:,d),lambda);
 %WW3.dec{1,2,2}(:,:,d)=0;
 % [LL3.dec{2,2,1}(:,:,d) WW3.dec{2,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{2,2,1}(:,:,d),lambda);  
 %[LL3.dec{2,2,2}(:,:,d) WW3.dec{2,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW3.dec{2,2,2}(:,:,d),lambda);  
   end

  for d=1:ceil(N/16)-1
  % [LL4.dec{1,1,1}(:,:,d) WW4.dec{1,1,1}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{1,1,1}(:,:,d),lambda);
   [LL4.dec{1,1,2}(:,:,d) WW4.dec{1,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{1,1,2}(:,:,d),lambda);
   
   [LL4.dec{2,1,1}(:,:,d) WW4.dec{2,1,1}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{2,1,1}(:,:,d),lambda);  
  [LL4.dec{2,1,2}(:,:,d) WW4.dec{2,1,2}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{2,1,2}(:,:,d),lambda);
   
 % [LL4.dec{1,2,1}(:,:,d) WW4.dec{1,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{1,2,1}(:,:,d),lambda);  
 % [LL4.dec{1,2,2}(:,:,d) WW4.dec{1,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{1,2,2}(:,:,d),lambda);
%WW4.dec{1,2,2}(:,:,d)=0;
 % [LL4.dec{2,2,1}(:,:,d) WW4.dec{2,2,1}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{2,2,1}(:,:,d),lambda);  
% [LL4.dec{2,2,2}(:,:,d) WW4.dec{2,2,2}(:,:,d)] = inexact_alm_rpca_wgs(WW4.dec{2,2,2}(:,:,d),lambda);  
  end
   
% Reconstruction
 WW3.dec{1,1,1}=idwt3(WW4);
 WW2.dec{1,1,1}=idwt3(WW3);
 WW1.dec{1,1,1}=idwt3(WW2);
 newimg3=idwt3(WW1);