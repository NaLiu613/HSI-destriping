function [A_hat E_hat iter] = inexact_alm_rpca_wgs(D, lambda, tol, maxIter)
%%  Revised by Na Liu 20180515  Replace sparsity with group sparsity ,i.e.,   |E|_1 ==> |E|_1,2 

% 
% Initialize A,E,Y,u
% while ~converged 
%   minimize (inexactly, update A and E only once)
%     L(A,E,Y,u) = |A|_* + lambda * |E|_1,2 + <Y,D-A-E> + mu/2 * |D-A-E|_F^2;
%   Y = Y + \mu * (D - A - E);
%   \mu = \rho * \mu;
% end


[m n] = size(D);

if nargin < 2
   lambda = 1 / sqrt(m)
      % lambda = 1e-2;
end

if nargin < 3
    tol = 1e-7;
elseif tol == -1
    tol = 1e-7;
end

if nargin < 4
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end

% initialize
%Y = zeros(m,n);
Y = D;
norm_one=norm(D(:),1);
norm_two = svds(D, 1, 'L');
norm_inf = norm( D(:), inf) / lambda;
dual_norm = max(norm_two, norm_inf);
Y = Y / dual_norm;
%Y = Y / norm_two;
A_hat = zeros( m, n);
E_hat = zeros( m, n);
mu =m*n/4/norm_one; % this one can be tuned   0.5184 for TG1
%mu=0.6;
%mu = 1.25/norm_two % this one can be tuned   0.0052 for TG1

mu_bar = mu * 1e7
%rho = 1.5       
rho =4.5%4.5 %2.5%1.5 % this one can be tuned
d_norm = norm(D, 'fro');

iter = 0;
total_svd = 0;
converged = false;
stopCriterion = 1;
sv = 1;

%W=sum(D,1)./m;

while ~converged       
    iter = iter + 1;
    iter
   
    %% ============================
  
    [U S V] = svds(D - E_hat + (1/mu)*Y, sv, 'L');
    diagS = diag(S);
    
     temp    = (diagS-1/mu).*double( (diagS-1/mu) > 0 );
    A_hat= U * diag(temp) * V';

   % A_hat = U(:, 1:svp) * diag(diagS(1:svp) - 1/mu) * V(:, 1:svp)';    
    total_svd = total_svd + 1;  

      %%  group sparsity
    temp_T = D - A_hat + (1/mu)*Y;
    
      for i=1:n
            W(i)=1/sqrt(norm(D(:,i),2));
         E_hat(:,i) = temp_T(:,i).*max(norm(temp_T(:,i),2) - W(i)*lambda/mu, 0)/(norm(temp_T(:,i),2)+eps);
    % E_hat(:,i)=max(temp_T(:,i)-(lambda/mu).*temp_T(:,i).*W(:,i)./norm(temp_T(:,i),2),0);
    %  E_hat(:,i)=E_hat(:,i)+min(temp_T(:,i)+(lambda/mu).*temp_T(:,i).*W(:,i)./norm(temp_T(:,i),2),0);
       end
  %  E_hat = max(temp_T - lambda/mu, 0);
   % E_hat = E_hat+min(temp_T + lambda/mu, 0);
   %%    
%% Y
    
    Z = D - A_hat - E_hat;   
    Y = Y + mu*Z;
    mu = min(mu*rho, mu_bar);
        
    %% stop Criterion    
    stopCriterion = norm(Z, 'fro') / d_norm;
    if stopCriterion < tol
        converged = true;
    end    
    
    if mod( total_svd, 10) == 0
        disp(['#svd ' num2str(total_svd) ' r(A) ' num2str(rank(A_hat))...
            ' |E|_0 ' num2str(length(find(abs(E_hat)>0)))...
            ' stopCriterion ' num2str(stopCriterion)]);
    end    
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end
