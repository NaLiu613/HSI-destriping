%% demo for Wavelet-Domain Low-Rank/Group-Sparse Destriping for Hyperspectral Imagery
%--------------Brief description-------------------------------------------
%
% 
% This demo implements WDLRGS destriping for HSI [1]
%
%
% More details in:
%
% [1] N. Liu, W. Li, R. Tao and J. Fowler, "Wavelet-Domain Low-Rank/Group-Sparse ...
% Destriping for Hyperspectral Imagery," in IEEE Transactions on Geoscience and Remote Sensing
% http://dx.doi.org/10.1109/TGRS.2019.2933555
%
% contact: liwei089@ieee.org (Wei Li),liuna@ieee.org (Na Liu)
% 
clear all; close all; clc
addpath(genpath('..\code_WDLRGS_destriping'))
% load DataTest.mat
% DataTest = DataTest / max(DataTest(:));

load pure_RemoteImage.mat
DataTest = Ori_H / max(Ori_H(:));

%% Add stripes
% % --------- Degraded simulation -------------------
rate = 0.6;
Mean=0.2;%std(DataTest(:))% (10/255)/max(DataTest(:));%;
Is   =  make_stripes(DataTest,rate,Mean);
%save Is.mat Is
Str=Is-DataTest;
band=20;
figure(1)
imshow(DataTest(:,:,band),[]);
figure(2)
imshow(Is(:,:,band),[]);
figure(3)
imshow(Str(:,:,band),[]);

%%  1 WDLRWGS
% User input parameters
lambda=1e-1;
  WS = struct('w1','db1','w2','db1','w3','db1');
 % WS = struct('w1','haar','w2','haar','w3','haar');

[Imgout]=dwt3decom(Is,lambda,WS);
figure(4)
imshow(Imgout(:,:,band),[]);